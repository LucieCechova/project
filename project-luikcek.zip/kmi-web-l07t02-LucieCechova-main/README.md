# kmi-web-l07t02

---

Dle [zadání úkolu](https://www.thomasparsley.cz/vyuka/2021-2022/kmi/tvorba-webovych-stranek/cviceni/responzivni-web#task-2) vypracujte řešení nejpozději do 19. 4. 2022 - 23:00.
